﻿# Sovereign Portable Application

## Quick Start
1. Double-click 'Sovereign_Launcher.bat' to start
2. Choose your preferred launch mode from the menu

## Files Included
- Sovereign.exe: Main GUI application
- xtra.exe: Command line interface
- Sovereign_Launcher.bat: Easy-to-use launcher menu
- webhooks.json: Configuration file
- INSTALL.md: Installation instructions
- LICENSE: License information

## System Requirements
- Windows 10/11
- Administrator privileges recommended for full features

## Launch Options
- GUI Mode: User-friendly interface (recommended)
- Admin Mode: Full privileges for advanced features
- CLI Mode: Command line interface for automation

## Support
This is a portable version that runs without installation.
All files must remain in the same folder.

Generated on: 2025-07-27 14:16:30
