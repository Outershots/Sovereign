# Roblox Driver Scanner - Installation Guide 
 
## Quick Start 
 
### GUI Version (Recommended): 
1. Double-click `RobloxDriverScanner.exe` 
2. Or use `Launch-GUI.bat` for easier access 
3. For full features, use `Launch-GUI-Admin.bat` (Administrator) 
 
### Command Line Version: 
1. Double-click `Launch-CLI.bat` 
2. Or run `RobloxDriverScanner-CLI.exe` from command prompt 
 
## Requirements 
- Windows 10/11 
- Administrator privileges recommended for full forensic analysis 
 
## Support 
For technical support, visit: [Your Website] 
